/*
Goals:
	Make use of several multithreading pthread calls, introduce threading, synchronistion, and resource protection and sharing. Also some vague notion of how a power system
	might be programmed.

	You must create a multi-threaded program that will share a battery. Your program must update the battery's voltage, current and temperature
	readings every second. We must also check these values to see that the values are within nominal range, and finally check to see if the system
	as a whole is doing okay.

	You should have at least three thread's in your program, all sharing a single resource that is the battery.

	First thread (every second):
		Updates the values of the battery's voltage, current, and temperature (use the given functions)

	second thread (every 3 seconds):
		Update the values of the state of the varies battery properties based on the nominal values, and the danger threashold. Also
		print the values to the terminal.

	Third thread (every five seconds):
		Check that there are no more than two properties in warning state, and none in critical state. If there are two or more values in warning state, or any in critical
		print a message to the terminal, and pause all thread execution for some amount of time, and restart all threads. If the program gets into this state three times in a row,
		the program will exit and report mission failure.

*/

#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h>   
#include <pthread.h>
#include <stdint.h>
#include <time.h>

#define VOLTAGE_SAFE			160
#define CURRENT_SAFE			1200
#define TEMPERATURE_SAFE		240
#define DANGER_THRESHOLD		2

#define NOMINAL					1
#define SYS_DANGER				2
#define LOW_VOLTAGE_WARNING 	3
#define LOW_VOLTAGE_CRITICAL 	4
#define LOW_CURRENT_WARNING		5
#define LOW_CURRENT_CRITICAL	6
#define TEMPERATURE_WARNING		7

typedef enum subsystem_EPS {
	EPS_CURRENT_VAL,
	EPS_CURRENT_STATE,
	EPS_VOLTAGE_VAL,
	EPS_VOLTAGE_STATE,
	EPS_TEMPERATURE_VAL,
	EPS_TEMPERATURE_STATE,
	EPS_ALERT,
	EPS_SIZE
};

uint16_t EPS_BATT[EPS_SIZE];

pthread_mutex_t BATTERY_ACCESS = PTHREAD_MUTEX_INITIALIZER;

uint16_t sc_get_voltage(void);
uint16_t sc_get_current(void);
uint16_t sc_get_temp(void);
void * sc_battery_usage(void);
void * sc_housekeeping(void);


void * sc_battery_usage(void) { // to query values and load them into the array
	for(;;) {
		pthread_mutex_lock(&BATTERY_ACCESS);
		EPS_BATT[EPS_VOLTAGE_VAL] = sc_get_voltage();
		EPS_BATT[EPS_CURRENT_VAL] = sc_get_current();
		EPS_BATT[EPS_TEMPERATURE_VAL] = sc_get_temp();
		pthread_mutex_unlock(&BATTERY_ACCESS);
		sleep(5);
	}
}


void * sc_housekeeping(void) { // to find values and check for nominal values
	for(;;) {
		pthread_mutex_lock(&BATTERY_ACCESS);
		printf("VOLTAGE: %u\n", EPS_BATT[EPS_VOLTAGE_VAL]);
		printf("CURRENT: %u\n", EPS_BATT[EPS_CURRENT_VAL]);
		printf("TEMP: %u\n", EPS_BATT[EPS_TEMPERATURE_VAL]);
		// get a snapshot of these values so we can release the lock
		uint16_t voltage = EPS_BATT[EPS_VOLTAGE_VAL];
		uint16_t current = EPS_BATT[EPS_CURRENT_VAL];
		uint16_t temperature = EPS_BATT[EPS_TEMPERATURE_VAL];
		pthread_mutex_unlock(&BATTERY_ACCESS);

		sleep(1);
	}
}


int main() {
	pthread_t th_housekeeping, th_battery_usage;

	if (pthread_mutex_init(&BATTERY_ACCESS, NULL)) { return -1; }
	if(pthread_create(&th_housekeeping, NULL, &sc_housekeeping, NULL)) { return -1; }
	if(pthread_create(&th_battery_usage, NULL, &sc_battery_usage, NULL)) { return -1; };
	
	pthread_join(th_housekeeping, NULL);
	pthread_join(th_battery_usage, NULL);
	pthread_mutex_destroy(&BATTERY_ACCESS);
	
	return 0;
}


/*******************************
	Imaginary spacecraft values
********************************/


uint16_t sc_get_voltage(void) {
	time_t V = time(0);
	uint16_t voltage = V/10000000 + (V/10 - V / 100 * 10);
}


uint16_t sc_get_current(void) {
	time_t V = time(0);
	uint16_t voltage = V/1000000 + (V/10 - V / 100 * 10) * 10;
}

uint16_t sc_get_temp(void) {
	time_t V = time(0);
	uint16_t voltage = V/1000000 + (V/10 - V / 100 * 10) * 100;
}
