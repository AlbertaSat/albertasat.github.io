#ifndef EPS_H_
#define EPS_H_

#include <inttypes.h>
#include <time.h>
#include <stdlib.h>
/*******************************
  Imaginary spacecraft values
********************************/
struct spaceCraft;
typedef struct spaceCraft spaceCraft_t;
uint16_t get_voltage();

struct spaceCraft
{
	uint16_t (*get_voltage_)(void);

	uint16_t (*get_current_)(void);

	uint16_t (*get_temp_)(void);
};
#endif