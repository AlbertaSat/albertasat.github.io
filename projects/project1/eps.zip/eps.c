#include "eps.h"

struct spaceCraft;

int rand_range(int min, int max) {
  srand(time(0)+clock()+rand());
  return (uint16_t) (rand() % (max - min + 1)) + min;
}

uint16_t get_voltage(void) {
	printf("dfasdf");
  return (uint16_t) rand_range(10, 20); // 18
}

uint16_t get_current(void) {
  return (uint16_t) rand_range(40, 50);
}

uint16_t get_temp(void) {
  return (uint16_t) rand_range(350, 360);
}
